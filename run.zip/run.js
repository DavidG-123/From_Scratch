WebGL2RenderingContext

const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");
ctx.fillStyle = "#ff6";
ctx.fillRect(0, 0, canvas.width, canvas.height);
// ctx.clearColor(0.0, 0.0, 0.0, 1.0);
// ctx.clear(ctx.COLOR_BUFFER_BIT);
var keyStates = ['false', 'false', 'false', 'false'];
var px=200, py=200;

function drawPlayer() {
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.clearRect(px, py, 8, 8)
    // console.log("done")
}

let godSpeed = 0;
function loadTick() {
    console.log('hit');
    document.addEventListener('keydown', function(event) {
        if (event.code == 'KeyW') {console.log("w"); keyStates[0] = 'true'}
        else if (event.code == 'KeyS') {console.log("s"); keyStates[1] = 'true'}
        else if (event.code == 'KeyA') {console.log("a"); keyStates[2] = 'true'}
        else if (event.code == 'KeyD') {console.log("d"); keyStates[3] = 'true'}});

    document.addEventListener('keyup', function(event) {
        if (event.code == 'KeyW') {console.log("-w"); keyStates[0] = 'false'}
        else if (event.code == 'KeyS') {console.log("-s"); keyStates[1] = 'false'}
        else if (event.code == 'KeyA') {console.log("-a"); keyStates[2] = 'false'}
        else if (event.code == 'KeyD') {console.log("-d"); keyStates[3] = 'false'}});

    setInterval(advanceTick ,33);
}
function advanceTick() {
    godSpeed = godSpeed += 1;
    // console.log(String(godSpeed + '\n' + 'sec: ' + (Math.floor(godSpeed/30)) + ' | ' + Math.floor(godSpeed / (godSpeed/30)) + '\n' + ctx));
    console.log(String(keyStates[0] + keyStates[1] + keyStates[2] + keyStates[3]))
    switch (String(keyStates[0] + keyStates[1] + keyStates[2] + keyStates[3])) {
        case "truefalsefalsefalse" : py -= 3; break;
        case "falsetruefalsefalse" : py += 3; break;
        case "falsefalsetruefalse" : px -= 3; break;
        case "falsefalsefalsetrue" : px += 3; break;
        case "truefalsefalsetrue" : py -=3, px +=3; break;
        case "falsetruefalsetrue" : py +=3, px +=3; break;
        case "falsetruetruefalse" : py +=3, px -=3; break;
        case "truefalsetruefalse" : py -=3, px -=3; break;
        case "truefalsetruetrue" : py -= 3; break;
        case "falsetruetruetrue" : py += 3; break;
        case "truetruetruefalse" : px -= 3; break;
        case "truetruefalsetrue" : px += 3; break;
    }
    drawPlayer()
    
    //document.getElementById("frames").innerHTML = String(godSpeed + '\n' + 'sec: ' + (Math.floor(godSpeed/30)) + ' | ' + (godSpeed / (godSpeed/30)));
}